# EuroAsia Education CRM — Telefon Ilovasi

Bu CRM tizimi **3 usulda** telefoningizga o'rnatilishi mumkin:

## 1️⃣ Eng oson yo'l: GitHub Pages + PWA (5 daqiqa)

PWA — bu veb-ilova bo'lib, telefonga "Ilovani o'rnatish" orqali App Drawer'ga qo'shiladi.

### Qadamlar:

1. **GitHub ombori oching:**
   - https://github.com/new → ombor nomi: `euroasia-app`
   - Public qiling, "Add a README file" ni belgilang → Create

2. **Fayllarni yuklang:**
   - `www` papkasidagi **barcha fayllarni** (`index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`) omborning ildiziga yuklang
   - Yoki terminal orqali:
     ```bash
     git clone https://github.com/SIZ/euroasia-app.git
     cd euroasia-app
     cp -r www/* .
     git add . && git commit -m "init" && git push
     ```

3. **GitHub Pages yoqing:**
   - Repository → **Settings** → **Pages** (chap menyuda)
   - Source: **Deploy from a branch**
   - Branch: **main**, folder: **/(root)** → Save

4. **Tayyor!** Sizning haqiqiy URL'ingiz:
   ```
   https://SIZ.github.io/euroasia-app/
   ```

5. **Telefonda o'rnatish:**
   - Android Chrome'da URL'ni oching
   - Pastda "Bosh ekranga qo'shish" yoki ⋮ menyu → "Ilovani o'rnatish"
   - Ilova App Drawer'ga chiqadi ✅
   - Internetga ulanmasdan ishlaydi ✅

> 🔁 Dastur kodi yangilanganda, telefondagi ilova avtomatik yangilanadi (service worker orqali).

---

## 2️⃣ APK fayl olish (Android .apk)

GitHub Actions orqali bepul APK yasaladi:

1. **Quyidagi fayllarni ombor ildiziga qo'ying:**
   - `.github/workflows/build-apk.yml` (tayyor berilgan)
   - `package.json` (tayyor berilgan)
   - `capacitor.config.json` (tayyor berilgan)
   - www/ papkasi (oldinga berilgan)

2. **Actions bo'limida Release APK workflow'ni toping:**
   - Repository → **Actions** → "Build Android APK" → **Run workflow**

3. **Build tugagach:**
   - Repository → **Releases** (yoki Actions → Build → Artifacts)
   - `app-debug.apk` yuklab oling

4. **Telefonga o'rnating:**
   - Telefon → Sozlamalar → Xavfsizlik → "Noma'lum manbalardan o'rnatish" ga ruxsat bering
   - APK'ni oching → O'rnatish

> APK chiqishi 5-10 daqiqa. SIZ o'rniga o'zingizning GitHub username'ingizni yozing.

---

## 3️⃣ Lokal build (kodingiz kompyuterda)

```bash
npm install
npx cap add android
npx cap sync
npx cap open android     # Android Studio'da ochiladi
# Android Studio'da: Build → Build Bundle(s) / APK(s) → Build APK(s)
```

---

## 📂 Fayl tuzilmasi

```
euroasia-app/
├── www/                      ← PWA uchun (GitHub Pages'ga to'g'ridan-to'g'ri)
│   ├── index.html
│   ├── manifest.json
│   ├── sw.js
│   ├── icon-192.png
│   ├── icon-512.png
│   └── apple-touch-icon.png
├── .github/workflows/
│   └── build-apk.yml        ← APK build workflow
├── package.json
├── capacitor.config.json
└── README.md
```

---

## Telefon funksiyalari

- ✅ **SMS** — ota-onaga avtomatik SMS yuborish (telefoningiz SMS ilovasi orqali)
- ✅ **Call** — bir bosish bilan qo'ng'iroq
- ✅ **Davomat**, **to'lov**, **guruhlar**, **AI yordamchi** — hammasi ishlaydi
- ✅ **Offline** — internet o'chsa ham ishlaydi (service worker)
- ✅ **Export/Import JSON** — ma'lumotlarni saqlash

## Talablar

- Android 7+ yoki iOS 12+
- Chrome / Safari so'nggi versiyasi
- PWA uchun HTTPS (GitHub Pages bepul beradi)
